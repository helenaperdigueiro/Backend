package com.helena.aula29;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula29ApplicationTests {

	@Test
	void contextLoads() {
	}

}
