package com.helena.aula27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula27ApplicationTests {

	@Test
	void contextLoads() {
	}

}
