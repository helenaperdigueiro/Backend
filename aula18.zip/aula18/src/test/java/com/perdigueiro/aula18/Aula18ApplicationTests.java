package com.perdigueiro.aula18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
