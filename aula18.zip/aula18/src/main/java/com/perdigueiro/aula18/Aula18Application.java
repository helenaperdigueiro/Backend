package com.perdigueiro.aula18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula18Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula18Application.class, args);
	}

}
