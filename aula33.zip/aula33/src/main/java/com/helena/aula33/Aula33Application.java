package com.helena.aula33;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula33Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula33Application.class, args);
	}

}
