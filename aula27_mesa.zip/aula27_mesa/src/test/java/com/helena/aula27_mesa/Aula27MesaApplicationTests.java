package com.helena.aula27_mesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula27MesaApplicationTests {

	@Test
	void contextLoads() {
	}

}
