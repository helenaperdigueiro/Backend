package com.helena.aula27_mesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula27MesaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula27MesaApplication.class, args);
	}

}
