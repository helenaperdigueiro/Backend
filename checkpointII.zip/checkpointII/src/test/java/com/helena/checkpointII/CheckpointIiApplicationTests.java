package com.helena.checkpointII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckpointIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
