package com.helena.aula27mesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula27mesaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula27mesaApplication.class, args);
	}

}
