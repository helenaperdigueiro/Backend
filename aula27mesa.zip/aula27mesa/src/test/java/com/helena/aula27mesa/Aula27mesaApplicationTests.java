package com.helena.aula27mesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula27mesaApplicationTests {

	@Test
	void contextLoads() {
	}

}
