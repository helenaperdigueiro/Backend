package com.helena.aula23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
