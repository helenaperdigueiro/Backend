package com.helena.aula23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula23Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula23Application.class, args);
	}

}
