package com.helena.aula2930;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula2930ApplicationTests {

	@Test
	void contextLoads() {
	}

}
